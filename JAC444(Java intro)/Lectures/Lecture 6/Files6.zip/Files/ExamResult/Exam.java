@FunctionalInterface
public interface Exam {
	String getExamResult(String name);
}
