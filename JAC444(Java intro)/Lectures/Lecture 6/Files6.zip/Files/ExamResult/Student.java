public class Student {
	public String name;
	
	Student(String s) {
		name = s;
	}
}
