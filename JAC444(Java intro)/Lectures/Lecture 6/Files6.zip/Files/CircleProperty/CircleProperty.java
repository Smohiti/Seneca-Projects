@FunctionalInterface
public interface CircleProperty {
	double get(double radius);
}
