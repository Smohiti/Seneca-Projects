public class ThirdExample {

	public static void TwoParams () {
		RunnerTwo r = new RunnerTwo();
		/** ??? **/
	}
}
