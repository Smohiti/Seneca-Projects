public class Car {
	String name;

	public Car(String n) {
		name = n;
	}

	String getName() {
		return name;
	}
}
