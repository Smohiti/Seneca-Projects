public class RunnerTwo {	
	public void run(ExecutableTwo e, String s1, String s2) {
		//two params
		e.executeTwo(s1, s2);
	}
}
