// functional interface - method with zero parameters
public interface ExecutableZero {
	void executeZero();
}
