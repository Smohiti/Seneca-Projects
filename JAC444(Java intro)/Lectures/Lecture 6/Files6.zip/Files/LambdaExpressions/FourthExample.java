public class FourthExample {

	public static void ObjectParam() {
		/** ??? **/
	}
}
