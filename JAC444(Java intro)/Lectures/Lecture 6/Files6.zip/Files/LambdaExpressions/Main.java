/**
 * Main class of the Java program.
 */
public class Main {

	public static void main(String[] args) {

		System.out.println("\nfunctional interface - method with zero parameters");
		FirstExample.ZeroParam();

		System.out.println("\nfunctional interface - method with one parameter");
		SecondExample.OneParam();

		System.out.println("\nfunctional interface - method with two parameters");
		ThirdExample.TwoParams();

		System.out.println("\nfunctional interface - method with one object parameter");
		FourthExample.ObjectParam();
	}
}
