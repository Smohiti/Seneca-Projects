public interface Executable {
	void execute(Car car);
}
