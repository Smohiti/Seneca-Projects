public class RunnerZero {
	public int i;

	public RunnerZero(int i) {
		this.i = i;
	}

	public void run(ExecutableZero e) {
		// zero param
		e.executeZero();
	}
}
