// functional interface - method with two parameters
public interface ExecutableTwo {
	void executeTwo(String p, String q);
}
