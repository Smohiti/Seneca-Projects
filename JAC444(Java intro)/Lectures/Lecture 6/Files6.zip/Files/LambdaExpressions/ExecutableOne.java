// functional interface - method with one parameter
public interface ExecutableOne {
	void executeOne(int i);
}
