public class RunnerOne {
	public int i;

	public RunnerOne(int i) {
		this.i = i;
	}
	public void run(ExecutableOne e) {
		//one param
		e.executeOne(i);
	}
}
