public class SecondExample {

	public static void OneParam() {

		RunnerOne r = new RunnerOne(1);

		// lambda expression that takes one parameter
		new RunnerOne(1).run( (k) -> {System.out.println("lambda with one param " + k);});
		// lambda expression that takes one parameter can omit parenthesis (k) could be k
		r.run( k -> System.out.println("lambda with one param without parenthesis and curely braces " + k + 1));

	}
}
