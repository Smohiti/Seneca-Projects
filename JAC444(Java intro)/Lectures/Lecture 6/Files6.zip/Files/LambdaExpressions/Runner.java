public class Runner {

	public void run(Executable e, Car car) {
		// an object param
		e.execute(car);
	}
}
