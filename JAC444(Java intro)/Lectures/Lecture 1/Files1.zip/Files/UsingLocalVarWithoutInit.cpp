#include <iostream>
using namespace std;

int main() {

	int i;
	cout << i << endl;

	return 0;

}
