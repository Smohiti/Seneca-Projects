public class WrongBoolean {

	public static void main(String[] args) {
		byte x = 1;
		boolean y = false;
		System.out.println(x & y);
	}
} 
