public class ArrayIndexOutOfBoundsInJava {

	public static void main(String[] args) {

		int[] array = new int[ 10 ];

		for( int i = 0; i <= 9; i++ ) {
			System.out.println( array[ i ] );
		}
		
	}
	
}