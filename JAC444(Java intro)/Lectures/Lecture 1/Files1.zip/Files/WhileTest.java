public class WhileTest {

	public static void main(String[] args) {

		int i = 1;
		
		while ( i == 1 ) {
			System.out.println( i );

			//...

			//if (...)
				i = 0;
		}
		
	}
	
}