#include <iostream>
using namespace std;

int main() {

	int i = 1;

	while ( i = 1 ) {
		cout << i << endl;

		//...

		//if (...)
			i = 0;
	}

	return 0;

}
