#include <iostream>
using namespace std;

int main() {

	int array[10];

	for( int i = -1; i <= 10; i++ ) {
		cout << i << " " << array[ i ] << endl;
	}

	return 0;

}
