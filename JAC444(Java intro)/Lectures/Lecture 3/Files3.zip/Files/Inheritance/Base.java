public class Base {
	public String s = "Base";

	public String show() {
		return s;
	}
}
